
// var clientAPI;

// /**
//  * Describe this function...
//  */
// export default function Z_WorkOrderSystemcondition(clientAPI) {
// }
import {ValueIfExists} from '../Common/Library/Formatter';

export default function Z_WorkOrderSystemcondition(context) {
    let binding = context.getBindingObject();
   // return ValueIfExists(binding.OrderDescription);
   //Start of change for testing systemcond
   return ValueIfExists(binding.SystemCond);
   //end of change for testing system condition 
}
