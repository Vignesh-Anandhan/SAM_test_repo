import {WorkOrderLibrary as LibWo} from './WorkOrderLibrary';

export default function WorkOrderPriorityFormat(context) {
    return LibWo.getWorkOrderPriorityFormat(context);
}
