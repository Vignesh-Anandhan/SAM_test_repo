import libCommon from '../Common/Library/CommonLibrary';

export default function NotificationSAPUserName(context) {
        return libCommon.getSapUserName(context);
}
