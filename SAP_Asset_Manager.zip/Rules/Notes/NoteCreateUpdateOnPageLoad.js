import {NoteLibrary as NoteLib} from './NoteLibrary';

export default function NoteCreateUpdateOnPageLoad(pageClientAPI) {

    NoteLib.createUpdateOnPageLoad(pageClientAPI);
}
