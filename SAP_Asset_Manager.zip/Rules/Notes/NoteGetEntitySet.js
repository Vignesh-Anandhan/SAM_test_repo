
import {NoteLibrary as NoteLib} from './NoteLibrary';

export default function NoteGetEntitySet(context) {

    return NoteLib.getEntitySet(context);
}
