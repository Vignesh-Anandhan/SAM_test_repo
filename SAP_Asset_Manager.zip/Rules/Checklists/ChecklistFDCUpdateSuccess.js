import { ChecklistLibrary as libChecklist } from './ChecklistLibrary';

export default function checklistFDCUpdateSuccess(context) {

    return libChecklist.checklistFDCUpdateSuccess(context);
}
