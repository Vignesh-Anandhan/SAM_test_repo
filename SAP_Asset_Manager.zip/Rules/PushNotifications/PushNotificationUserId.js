export default function PushNotificationUserId(context) {
    return context.evaluateTargetPath('#Application/#ClientData/#Property:UserId'); 
}
