import {TimeSheetLibrary as libTS} from './TimeSheetLibrary';

export default function TimeSheetEntryAttendAbsenceQueryOptions(clientAPI) {
    return libTS.TimeSheetEntryAttendAbsenceQueryOptions(clientAPI);
}
